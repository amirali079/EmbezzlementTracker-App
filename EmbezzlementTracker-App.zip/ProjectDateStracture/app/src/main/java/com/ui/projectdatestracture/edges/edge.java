package com.ui.projectdatestracture.edges;

public abstract class edge {

    public abstract void setKey(String key);
    public abstract String getKey();

    public abstract void setFrom(Object from);
    public abstract Object getFrom();

    public abstract void setTo(Object from);
    public abstract Object getTo();


}


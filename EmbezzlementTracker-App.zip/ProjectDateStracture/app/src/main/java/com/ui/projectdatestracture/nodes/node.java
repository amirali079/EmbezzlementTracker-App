package com.ui.projectdatestracture.nodes;

public abstract class node {
    public abstract void setKey(String key);
    public abstract String getKey();
}

package com.ui.projectdatestracture.nodes;


public abstract class mamlok extends node {
}

package com.ui.projectdatestracture.nodes;


public enum vasiat{fALSE,ghachaghchi,maznon,h1,h2,h3,h4,h5}